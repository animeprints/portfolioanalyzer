<?php
require_once __DIR__ . '/vendor/autoload.php';
$cors = new \App\Middleware\CorsMiddleware();
$cors->handle();
header('Content-Type: application/json');
echo json_encode(['test'=>'ok']);
