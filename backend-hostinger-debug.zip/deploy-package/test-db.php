<?php
header('Content-Type: application/json');

// Test database connection
require_once __DIR__ . '/config/database.php';

try {
    $pdo = getDbConnection();
    $stmt = $pdo->query("SELECT 1");
    $result = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'message' => 'Database connection successful',
        'database' => $_ENV['DB_NAME'] ?? 'unknown',
        'user' => $_ENV['DB_USER'] ?? 'unknown',
        'test_result' => $result
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed',
        'error' => $e->getMessage(),
        'hint' => 'Check if .env file exists and has correct DB credentials'
    ]);
}
