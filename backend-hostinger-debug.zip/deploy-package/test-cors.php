<?php
// Load the same initialization as index.php to test CORS properly
ob_start();
require_once __DIR__ . '/vendor/autoload.php';
try {
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
} catch (Exception $e) {
    // .env might not exist, that's okay
}

// Now apply CORS middleware
require_once __DIR__ . '/middleware/cors.php';
$cors = new \App\Middleware\CorsMiddleware();
$cors->handle();

// Return diagnostics
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'CORS test endpoint',
    'timestamp' => date('c'),
    'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
    'origin_header_received' => $_SERVER['HTTP_ORIGIN'] ?? 'none',
    'allowed_origins_configured' => $_ENV['ALLOWED_ORIGINS'] ?? 'using hardcoded defaults',
    'cors_headers_sent' => [
        'Access-Control-Allow-Origin' => $_SERVER['HTTP_ACCESS_CONTROL_ALLOW_ORIGIN'] ?? 'not set (origin not matched or not preflight)',
        'Access-Control-Allow-Credentials' => 'should be present',
        'Access-Control-Allow-Methods' => $_SERVER['HTTP_ACCESS_CONTROL_ALLOW_METHODS'] ?? 'not set',
    ],
    'test_instructions' => 'Use browser DevTools Network tab or curl -H "Origin: https://portfolioanalyzer-three.vercel.app" to test preflight'
], JSON_PRETTY_PRINT);
