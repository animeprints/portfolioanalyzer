<?php
// Comprehensive diagnostics for deployment issues
header('Content-Type: application/json');

$diagnostics = [
    'timestamp' => date('c'),
    'php_version' => PHP_VERSION,
    'environment' => [
        'ALLOWED_ORIGINS' => $_ENV['ALLOWED_ORIGINS'] ?? 'not set',
        'DB_NAME' => $_ENV['DB_NAME'] ?? 'not set',
        'DB_USER' => $_ENV['DB_USER'] ?? 'not set',
        'DB_PASS_set' => isset($_ENV['DB_PASS']) ? 'set' : 'not set',
    ],
    'files' => [],
    'database' => null,
];

// Check .env file
$envPath = __DIR__ . '/.env';
$diagnostics['files']['.env'] = [
    'exists' => file_exists($envPath),
    'readable' => is_readable($envPath),
    'size' => file_exists($envPath) ? filesize($envPath) : 0,
];

// If .env exists, try to parse it manually
if (file_exists($envPath) && is_readable($envPath)) {
    $envContent = file_get_contents($envPath);
    preg_match('/DB_NAME=(.+)/', $envContent, $dbNameMatch);
    preg_match('/DB_USER=(.+)/', $envContent, $dbUserMatch);
    preg_match('/ALLOWED_ORIGINS=(.+)/', $envContent, $originsMatch);

    $diagnostics['parsed_env'] = [
        'DB_NAME' => $dbNameMatch[1] ?? 'not found',
        'DB_USER' => $dbUserMatch[1] ?? 'not found',
        'ALLOWED_ORIGINS' => $originsMatch[1] ?? 'not found',
    ];
}

// Test database connection
try {
    require_once __DIR__ . '/config/database.php';
    $pdo = \App\Config\Database::getConnection();

    // Test query
    $stmt = $pdo->query("SELECT DATABASE() as db, USER() as user");
    $result = $stmt->fetch();

    $diagnostics['database'] = [
        'connected' => true,
        'database' => $result['db'],
        'user' => $result['user'],
        'tables_exist' => []
    ];

    // Check for users table
    $tables = ['users', 'profiles'];
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("DESCRIBE `$table`");
            $diagnostics['database']['tables_exist'][$table] = true;
        } catch (\Exception $e) {
            $diagnostics['database']['tables_exist'][$table] = false;
        }
    }

} catch (\Exception $e) {
    $diagnostics['database'] = [
        'connected' => false,
        'error' => $e->getMessage(),
    ];
}

// Check upload directory
$uploadDir = __DIR__ . '/upload';
$diagnostics['upload_dir'] = [
    'exists' => file_exists($uploadDir),
    'writable' => file_exists($uploadDir) && is_writable($uploadDir),
    'permissions' => file_exists($uploadDir) ? substr(sprintf('%o', fileperms($uploadDir)), -4) : 'N/A',
];

echo json_encode($diagnostics, JSON_PRETTY_PRINT);
